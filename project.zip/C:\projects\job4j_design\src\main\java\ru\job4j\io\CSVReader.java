package ru.job4j.io;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringJoiner;

public class CSVReader {
    public static void handle(ArgsName argsName) throws IOException {
        Path data = Path.of("data/read.csv");
//        var scanner = new Scanner(new ByteArrayInputStream(data))
//                .useDelimiter(";");
//        while (scanner.hasNext()) {
//            System.out.println(scanner.next());
        }
//    }


    public static void main(String[] args) throws IOException {
        /* здесь добавьте валидацию принятых параметров*/
        ArgsName argsName = ArgsName.of(args);
        handle(argsName);
    }
}